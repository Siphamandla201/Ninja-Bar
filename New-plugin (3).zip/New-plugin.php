<?php

/*
 * Plugin Name:       Ninja Bar
 * Description:       Removes the admin bar from the front end when viewing site
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Siphamandla Mlanjana
*/

add_filter( 'show_admin_bar', '__return_false' );


add_action( 'admin_menu', 'wporg_options_page' );
function wporg_options_page() {
    add_menu_page(
        'Ninja Bar',
        'Ninja Bar',
        'manage_options',
        'wporg',
        'wporg_options_page_html',
        'dashicons-hidden',
        20
    );
}

function wporg_options_page_html() {
    // Code to display the content of the options page
    echo '<h1>Ninja Bar</h1>';
    echo '<p>Options page still under development.</p>';
}

